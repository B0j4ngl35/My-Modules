#!/system/bin/sh

settings put secure rtt_calling_mode 0