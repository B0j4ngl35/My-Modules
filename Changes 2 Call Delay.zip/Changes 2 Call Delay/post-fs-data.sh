#!/sbin/sh
#By Roderick
busybox echo "ro.telephony.call_ring.delay=0
ring.delay=0" >> /system/build.prop